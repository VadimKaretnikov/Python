


if __name__ == '__main__':
    num = int(input("Введите число"))
    max_cif = 0
    while num > 0:
        num10 = num // 10
        cif = num - (10 * num10)
        if cif > max_cif:
            max_cif = cif
        num = num10
    print("Максимальная цифра: ", max_cif)
