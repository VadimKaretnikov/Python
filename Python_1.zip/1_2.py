


if __name__ == '__main__':
    sec = int(input("Введите время в секундах"))
    hours = sec // 3600
    minutes = (sec - 3600 * hours) // 60
    seconds = (sec - 3600 * hours - 60 * minutes)
    print("%02d:%02d:%02d" % (hours, minutes, seconds))




