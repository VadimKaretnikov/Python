
import math

if __name__ == '__main__':
    a = float(input("Сколько км в первый день?"))
    b = float(input("Сколько км нужно пробежать?"))
    days = math.log((b / a), 1.1) // 1 + 1
    print("Нужная дистанция будет преодолена через ", days, " дней")


