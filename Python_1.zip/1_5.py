


if __name__ == '__main__':
    income = float(input("Введите выручку"))
    spendings = float(input("Введите издержки"))
    if income > spendings:
        print("Предприятие работает успешно")
        profit = income - spendings
        ratio = profit / income
        print("Рентабельность: ", ratio)
        workers_cnt = int(input("Введите число сотрудников"))
        profit_per_worker = profit / workers_cnt
        print("Прибыль в расчете на одного сотрудника: ", profit_per_worker)
    else:
        print("Предприятие работает в убыток")

