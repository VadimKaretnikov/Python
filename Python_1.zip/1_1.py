


if __name__ == '__main__':
    a = 4
    b = 'f'
    print(a)
    print(b)
    c = input("Введите строку: ")
    d = int(input("Введите число: "))
    print(c)
    print(d)


