


if __name__ == '__main__':
    num = int(input("Введите число"))
    numm = (num * 100) + (num * 10) + num
    print(numm)




